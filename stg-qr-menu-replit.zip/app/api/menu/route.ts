import path from 'path';
import { promises as fs } from 'fs';
import { parseCSV } from '@/lib/csv';
export async function GET(){
  try {
    const filePath = path.join(process.cwd(), 'public', 'data', 'menu.csv');
    const csv = await fs.readFile(filePath, 'utf8');
    const items = parseCSV(csv);
    return new Response(JSON.stringify({items}), { headers: { 'content-type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({error: 'CSV not found'}), { status: 500, headers: { 'content-type': 'application/json' } });
  }
}
