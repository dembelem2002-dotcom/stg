import Header from '@/components/Header';
import MenuList from '@/components/MenuList';
import { parseCSV, type MenuItem } from '@/lib/csv';
import { notFound } from 'next/navigation';
import path from 'path';
import { promises as fs } from 'fs';

export default async function MenuPage({ params, searchParams }:{ params:{tableCode:string}, searchParams: { [key:string]: string|string[]|undefined } }){
  const table = params.tableCode;
  const lang = (searchParams.lang as string) === 'de' ? 'de' : 'en';
  const mode = (searchParams.mode as string) ?? 'dine-in';
  const filePath = path.join(process.cwd(), 'public', 'data', 'menu.csv');
  let csv = '';
  try { csv = await fs.readFile(filePath, 'utf8'); } catch (e) { console.error('Missing CSV at public/data/menu.csv', e); notFound(); }
  const items: MenuItem[] = parseCSV(csv);
  return (
    <div className="card">
      <Header />
      <div className="small">Table: <strong>{table}</strong> • Items: {items.length}</div>
      <MenuList items={items} lang={lang as any} mode={mode} />
    </div>
  );
}
