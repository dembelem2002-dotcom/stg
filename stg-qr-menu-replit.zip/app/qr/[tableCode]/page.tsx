import { redirect } from 'next/navigation';
export default function QR({ params, searchParams }:{params:{tableCode:string}, searchParams:Record<string, string|undefined>}){
  const mode = searchParams.mode ?? 'dine-in';
  redirect(`/menu/${encodeURIComponent(params.tableCode)}?mode=${mode}`);
}
