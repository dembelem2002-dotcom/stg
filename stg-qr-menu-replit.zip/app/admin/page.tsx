'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
type Item = { id:string; name:string; };
export default function Admin(){
  const [items, setItems] = useState<Item[]>([]);
  const [sold, setSold] = useState<Record<string, boolean>>({});
  useEffect(()=>{
    (async ()=>{
      const res = await fetch('/api/menu');
      const data = await res.json();
      setItems(data.items.map((i:any)=>({id:i.id, name:i.name_en})));
      const s:Record<string, boolean> = {};
      data.items.forEach((i:any)=>{ s[i.id] = localStorage.getItem(`soldout:${i.id}`) === '1'; });
      setSold(s);
    })();
  },[]);
  const toggle = (id:string) => {
    const newVal = !sold[id];
    setSold(prev=>({...prev,[id]:newVal}));
    if (newVal) localStorage.setItem(`soldout:${id}`,'1'); else localStorage.removeItem(`soldout:${id}`);
  };
  return (
    <div className="card">
      <div className="header">
        <strong>Admin (local demo)</strong>
        <Link className="badge" href="/menu/T45">Back to menu</Link>
      </div>
      <p className="small">Flags stored in your browser. Replace with DB later.</p>
      <table><thead><tr><th>ID</th><th>Name</th><th>Sold out</th></tr></thead>
        <tbody>{items.map(i=>(<tr key={i.id}><td className="small">{i.id}</td><td>{i.name}</td>
          <td><label style={{display:'inline-flex',alignItems:'center',gap:8}}>
            <input type="checkbox" checked={!!sold[i.id]} onChange={()=>toggle(i.id)} /><span className="small">{sold[i.id] ? 'Yes' : 'No'}</span>
          </label></td></tr>))}</tbody></table>
    </div>
  );
}
