'use client';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
export default function Home() {
  const router = useRouter();
  const sp = useSearchParams();
  const existingMode = sp.get('mode') ?? 'dine-in';
  const [table, setTable] = (require('react') as any).useState('T45');
  const [mode, setMode] = (require('react') as any).useState(existingMode);
  const go = () => { router.push(`/menu/${encodeURIComponent(table)}?mode=${mode}`); };
  return (
    <div className="card">
      <h1>Welcome to STG QR Menu</h1>
      <p className="small">Replit-ready demo. CSV-driven. Try Dine-In or Take-Away.</p>
      <div className="grid grid-2" style={{marginTop:12}}>
        <button className={`btn ${mode==='dine-in'?'btn-accent':''}`} onClick={()=>setMode('dine-in')}>Dine-In</button>
        <button className={`btn ${mode==='take-away'?'btn-accent':''}`} onClick={()=>setMode('take-away')}>Take-Away</button>
      </div>
      <div style={{marginTop:14}}>
        <label className="small">Table code</label>
        <input className="input" value={table} onChange={e=>setTable(e.target.value)} placeholder="e.g., T45"/>
      </div>
      <div style={{marginTop:14}}><button className="btn btn-accent" onClick={go}>Open Menu</button></div>
      <hr/>
      <div className="small">Direct link: <Link href="/menu/T45">/menu/T45</Link></div>
    </div>
  );
}
