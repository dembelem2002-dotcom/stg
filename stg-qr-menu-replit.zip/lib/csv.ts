export type MenuItem = {
  id: string;
  category: string;
  name_en: string;
  name_de?: string;
  description_en?: string;
  description_de?: string;
  price: number;
  image?: string;
  available?: boolean;
};
export function parseCSV(csv: string): MenuItem[] {
  const lines = csv.split(/\r?\n/).filter(l => l.trim().length);
  const header = lines[0].split(',').map(h => h.trim());
  const rows = lines.slice(1);
  const items: MenuItem[] = [];
  for (const row of rows) {
    const cols: string[] = [];
    let cur = '', inQ = false;
    for (let i=0;i<row.length;i++){
      const ch = row[i];
      if (ch === '"'){ if (row[i+1] === '"'){ cur+='"'; i++; } else { inQ = !inQ; } }
      else if (ch === ',' && !inQ){ cols.push(cur); cur=''; }
      else { cur += ch; }
    }
    cols.push(cur);
    const rec: any = {};
    header.forEach((h,idx)=> rec[h] = (cols[idx]??'').trim());
    const price = parseFloat((rec.price || '0').replace(',', '.'));
    const available = (rec.available??'').toString().toLowerCase() !== 'false';
    items.push({
      id: rec.id, category: rec.category, name_en: rec.name_en, name_de: rec.name_de,
      description_en: rec.description_en, description_de: rec.description_de,
      price: isNaN(price) ? 0 : price, image: rec.image || undefined, available
    });
  }
  return items;
}
