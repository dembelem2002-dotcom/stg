Replit-ready Next.js QR menu. Press **Run** to build & start.
- Public menu: /menu/T45
- QR redirect: /qr/T45
- Admin (demo): /admin
