'use client';
import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
export default function Header() {
  const sp = useSearchParams();
  const pathname = usePathname();
  const lang = sp.get('lang') ?? 'en';
  const mode = sp.get('mode') ?? 'dine-in';
  const toggleLang = lang === 'en' ? 'de' : 'en';
  const makeUrl = (l:string) => {
    const params = new URLSearchParams(sp.toString());
    params.set('lang', l);
    return `${pathname}?${params.toString()}`;
  };
  return (
    <div className="header">
      <Link href={`/?mode=${mode}`}><strong>STG QR Menu</strong></Link>
      <div className="grid" style={{gridTemplateColumns:'auto auto auto', gap:8}}>
        <span className="badge">{mode.toUpperCase()}</span>
        <Link className="badge" href={makeUrl(toggleLang)}>{lang === 'en' ? 'DE' : 'EN'}</Link>
        <Link className="badge" href="/admin">Admin</Link>
      </div>
    </div>
  );
}
