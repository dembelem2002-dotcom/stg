'use client';
import { useMemo, useState } from 'react';
import type { MenuItem } from '@/lib/csv';
type Props = { items: MenuItem[]; lang: 'en'|'de'; mode: string; }
export default function MenuList({items, lang, mode}: Props){
  const [query, setQuery] = useState('');
  const itemsWithState = useMemo(()=> items.map(i=>{
    const sold = (typeof window !== 'undefined') && localStorage.getItem(`soldout:${i.id}`) === '1';
    return {...i, available: i.available !== false && !sold};
  }), [items]);
  const filtered = useMemo(()=>{
    const q = query.trim().toLowerCase();
    const arr = itemsWithState.filter(i=>{
      const name = (lang==='en'? i.name_en : i.name_de || i.name_en) || '';
      const desc = (lang==='en'? i.description_en : i.description_de || i.description_en) || '';
      return name.toLowerCase().includes(q) || desc.toLowerCase().includes(q) || i.category.toLowerCase().includes(q);
    });
    const map: Record<string, MenuItem[]> = {};
    for (const it of arr){ map[it.category] ??= []; map[it.category].push(it); }
    return map;
  }, [query, itemsWithState, lang]);
  return (
    <div>
      <div className="search">
        <input className="input" placeholder={lang==='en'?'Search menu...':'Suche in der Karte...'}
               value={query} onChange={e=>setQuery(e.target.value)} />
      </div>
      {Object.keys(filtered).sort().map(cat=> (
        <div key={cat}>
          <h2>{cat}</h2>
          <div className="grid">
            {filtered[cat].map(it=>{
              const name = (lang==='en'? it.name_en : it.name_de || it.name_en);
              const desc = (lang==='en'? it.description_en : it.description_de || it.description_en);
              return (
                <div className={`item ${it.available? '' : 'soldout'}`} key={it.id}>
                  {it.image ? <img src={it.image} alt={name} /> : <div style={{width:72,height:72,border:'1px dashed #333',borderRadius:10,display:'grid',placeItems:'center'}}>🍽️</div>}
                  <div style={{flex:1}}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',gap:10}}>
                      <div><strong>{name}</strong>{!it.available && <span className="badge" style={{marginLeft:8}}>{lang==='en'?'Sold out':'Ausverkauft'}</span>}</div>
                      <div className="price">{it.price.toFixed(2)} €</div>
                    </div>
                    {desc && <div className="small">{desc}</div>}
                    <div className="small tag">{lang==='en'?'Mode:':'Modus:'} {mode}</div>
                  </div>
                </div>
              );
            })}
          </div>
          <hr/>
        </div>
      ))}
      <div className="footer small">Powered by STG QR Menu • CSV-driven • Replit ready</div>
    </div>
  );
}
